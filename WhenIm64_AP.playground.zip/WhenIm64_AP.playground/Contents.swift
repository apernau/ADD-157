import UIKit

// define class

class overTheHill {
    var birthday: Date
    
// set the initializer
    init(birthday: Date) {
        self.birthday = birthday
    }
    
// define function to calculate year
    func turning64() -> Int? {
        let calendar = Calendar.current
        let sixtyFourthBirthday = calendar.date(bySetting: .year, value: calendar.component(.year, from: birthday) + 64, of: birthday)
        if let date = sixtyFourthBirthday {
            return calendar.component(.year, from: date)
        }
        return nil
    }
    
// define method to convert date into string
    func futureBirthday(date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateStyle = .long
        return formatter.string(from: date)
    }
}

// instantiate class

let dateFormatter = DateFormatter()
dateFormatter.dateFormat = "yyyy/MM/dd"

if let birthday = dateFormatter.date(from: "1989/07/14") {
    let calculator = overTheHill(birthday: birthday)
    
    if let your64 = calculator.turning64() {
        print("You will be turning 64 in the year \(your64)")
    }
}

