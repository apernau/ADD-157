import UIKit

// Define variables with random numbers

var number1 = Int.random(in: 1...100)
var number2 = Int.random(in: 1...100)
var number3 = Int.random(in: 1...100)
var number4 = Int.random(in: 1...100)
var number5 = Int.random(in: 1...100)

// Define constants with random numbers

let number1C = Int.random(in: 1...100)
let number2C = Int.random(in: 1...100)
let number3C = Int.random(in: 1...100)
let number4C = Int.random(in: 1...100)
let number5C = Int.random(in: 1...100)

//Add variables and constants into an array

var numbers = [number1, number2, number3, number4, number5, number1C, number2C, number3C, number4C, number5C]

//Sort into ascending order

numbers.sort()

//Store numbers into a dictionary

let dictionary: [String: Int] = [
    "highest": numbers.first!,
    "lowest": numbers.last!
]


//Print results

print("sorted: \(numbers)")
print("highest: \(dictionary["highest"]!)")
print("lowest: \(dictionary["lowest"]!)")
